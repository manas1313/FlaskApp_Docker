# -*- coding: utf-8 -*-
"""
Created on Tue Jun 30 13:53:53 2020

@author: routm1
"""

from flask_caching import Cache

cache = Cache()