# -*- coding: utf-8 -*-
"""
Created on Mon Jun 29 03:39:08 2020

@author: routm1
"""

   
def info():
    
    info_dist = {
    "name" : "FlaskApp_Dockers-Manas Rout",
    "version" : '0.0.2',
    "author" : "Manas Rout",
    "author_email" : "Manas.Rout@anz.com"
    }
    return info_dist 